from upestatic.base import Base

from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy import Integer, DateTime, Text
from sqlalchemy_json import mutable_json_type
from sqlalchemy.orm import relationship
from sqlalchemy import Column


class VolSurface(Base):
    __tablename__ = "vol_surfaces"
    vol_surface_id = Column(Integer, primary_key=True)
    model_type = Column(Text, nullable=False)
    expiry = Column(DateTime(timezone=True), nullable=False)
    params = Column(mutable_json_type(JSON, nested=True), nullable=False)

    historical_surfaces = relationship(
        "HistoricalVolSurface", back_populates="live_vol_surface"
    )
