from upestatic.base import Base

from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION

from sqlalchemy import Text, Date, Column, ForeignKey, Integer


class ExternalPnL(Base):
    __tablename__ = "external_pnls"

    pnl_date = Column(Date, primary_key=True)
    product_symbol = Column(Text, ForeignKey("products.symbol"), primary_key=True)
    source = Column(Text, primary_key=True)
    t1_trades = Column(DOUBLE_PRECISION, nullable=False)
    pos_pnl = Column(DOUBLE_PRECISION, nullable=False)
    gross_pnl = Column(DOUBLE_PRECISION, nullable=False)
    portfolio_id = Column(
        Integer, ForeignKey("portfolios.portfolio_id"), nullable=False
    )

    product = relationship(
        "Product",
        foreign_keys=product_symbol,
        back_populates="external_pnls",
        lazy="immediate",
    )
    portfolio = relationship(
        "Portfolio",
        foreign_keys=portfolio_id,
        back_populates="external_pnls",
    )
