from upestatic.base import Base

from sqlalchemy import Column, ForeignKey, Float, Text, Date


class SettlementVol(Base):
    __tablename__ = "settlement_vols"
    settlement_date = Column(Date, primary_key=True)
    option_symbol = Column(Text, ForeignKey("options.symbol"), primary_key=True)
    strike = Column(Float, primary_key=True)
    volatility = Column(Float, nullable=False)
