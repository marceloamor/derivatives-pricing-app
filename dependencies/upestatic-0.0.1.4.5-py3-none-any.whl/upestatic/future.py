import upestatic.future_price_feed_association
from upestatic.base import Base
import upestatic.product
import upestatic.option

from sqlalchemy import ForeignKey, Integer, DateTime, Text, Column
from sqlalchemy.orm import relationship


class Future(Base):
    __tablename__ = "futures"

    symbol = Column(Text, primary_key=True)
    display_name = Column(Text, nullable=True)
    expiry = Column(DateTime(timezone=True), nullable=False)
    multiplier = Column(Integer, default=1, nullable=False)
    product_symbol = Column(ForeignKey("products.symbol"), nullable=False)

    product = relationship("Product", back_populates="futures")
    underlying_feeds = relationship(
        "FuturePriceFeedAssociation",
        back_populates="future",
    )
    options = relationship("Option", back_populates="underlying_future")
