from upestatic import vol_surface
from upestatic.base import Base

from sqlalchemy import Integer, DateTime, Text, ForeignKey
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy_json import mutable_json_type
from sqlalchemy import Column


class HistoricalVolSurface(Base):
    __tablename__ = "historical_vol_params"
    update_datetime = Column(DateTime(timezone=True), primary_key=True)
    vol_surface_id = Column(
        Integer, ForeignKey("vol_surface.VolSurface"), primary_key=True
    )
    model_type = Column(Text, nullable=False)
    expiry = Column(DateTime(timezone=True), nullable=False)
    params = Column(mutable_json_type(JSON, nested=True), nullable=False)
