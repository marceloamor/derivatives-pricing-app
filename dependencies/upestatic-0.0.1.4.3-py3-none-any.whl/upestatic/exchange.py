from upestatic.base import Base
import upestatic.product

from sqlalchemy.orm import relationship
from sqlalchemy import Text, Column


class Exchange(Base):
    __tablename__ = "exchanges"
    symbol = Column(Text, primary_key=True)
    name = Column(Text, nullable=False)

    products = relationship("Product", back_populates="exchange")
