import upestatic.future_price_feed_association
from upestatic.enums import VolType, TimeType
from upestatic.vol_surface import VolSurface
from upestatic.base import Base
import upestatic.product
import upestatic.future
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION
from sqlalchemy.orm import relationship
from sqlalchemy import (
    ForeignKey,
    DateTime,
    Column,
    ARRAY,
    Integer,
    Text,
    Enum,
)


class Option(Base):
    __tablename__ = "options"
    symbol = Column(Text, primary_key=True)
    display_name = Column(Text, nullable=True)
    product_symbol = Column(Text, ForeignKey("products.symbol"), nullable=False)
    vol_surface_id = Column(
        Integer, ForeignKey("vol_surfaces.vol_surface_id"), nullable=False
    )
    underlying_future_symbol = Column(
        Text, ForeignKey("futures.symbol"), nullable=False
    )
    strike_intervals = Column(ARRAY(Integer, dimensions=2), nullable=False)

    time_type = Column(Enum(TimeType, name="time_type"), nullable=False)
    multiplier = Column(DOUBLE_PRECISION, nullable=False)
    vol_type = Column(Enum(VolType, name="vol_type"), nullable=False)
    expiry = Column(DateTime(timezone=True), nullable=False)

    product = relationship(
        "Product",
        foreign_keys=product_symbol,
        back_populates="options",
        lazy="immediate",
    )
    vol_surface = relationship(
        "VolSurface", foreign_keys=vol_surface_id, lazy="immediate"
    )
    underlying_future = relationship(
        "Future",
        foreign_keys=underlying_future_symbol,
        back_populates="options",
        lazy="immediate",
    )
