import upestatic.future_price_feed_association
from upestatic.base import Base

from sqlalchemy import Boolean, Text, Column
from sqlalchemy.orm import relationship


class PriceFeed(Base):
    __tablename__ = "price_feeds"

    feed_id = Column(Text, primary_key=True)
    origin = Column(Text, primary_key=True)
    delayed = Column(Boolean, nullable=False)
    subscribe = Column(Boolean, nullable=False)

    futures = relationship(
        "FuturePriceFeedAssociation",
        back_populates="feed",
    )
