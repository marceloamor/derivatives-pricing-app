from upestatic.base import Base

from sqlalchemy.orm import relationship
from sqlalchemy import Text, Column, Integer


class Trader(Base):
    __tablename__ = "traders"
    trader_id = Column(Integer, primary_key=True)
    display_name = Column(Text, nullable=False)
    email = Column(Text, nullable=False)
    full_name = Column(Text, nullable=False)
    is_algo = Column(Integer, nullable=False, default=False)

    portfolios = relationship("Portfolio", back_populates="trader")
