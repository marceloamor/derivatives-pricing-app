from upestatic.base import Base
import upestatic.price_feed
import upestatic.product
import upestatic.future
import upestatic.option

from sqlalchemy import ForeignKey, ForeignKeyConstraint, Column, Text
from sqlalchemy.dialects.postgresql import DOUBLE_PRECISION
from sqlalchemy.orm import relationship


class FuturePriceFeedAssociation(Base):
    __tablename__ = "future_price_feed_associations"
    __table_args__ = (
        ForeignKeyConstraint(
            ["feed_id", "feed_origin"],
            ["price_feeds.feed_id", "price_feeds.origin"],
            name="future_price_feed_assoc_feed_comp_fkey",
        ),
    )
    future_symbol = Column(Text, ForeignKey("futures.symbol"), primary_key=True)
    feed_id = Column(Text, primary_key=True)
    feed_origin = Column(Text, primary_key=True)
    weighting = Column(DOUBLE_PRECISION, default=1.0, primary_key=True)

    future = relationship("Future", back_populates="underlying_feeds", lazy="immediate")
    feed = relationship(
        "PriceFeed",
        back_populates="futures",
        lazy="immediate",
        foreign_keys="[FuturePriceFeedAssociation.feed_id, FuturePriceFeedAssociation.feed_origin]",
    )
