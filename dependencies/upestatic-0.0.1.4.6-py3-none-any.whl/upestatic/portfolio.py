from upestatic.base import Base

from sqlalchemy.orm import relationship
from sqlalchemy import Text, Column, Integer, ForeignKey


class Portfolio(Base):
    __tablename__ = "portfolios"
    portfolio_id = Column(Integer, primary_key=True)
    display_name = Column(Text, nullable=False)
    owner_trader_id = Column(Integer, ForeignKey("traders.trader_id"), nullable=False)

    external_pnls = relationship("ExternalPnL", back_populates="portfolio")
    trader = relationship("Trader", back_populates="portfolios")
