import upestatic.price_feed
import upestatic.product
from upestatic.base import Base
import upestatic.future
import upestatic.option

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import ForeignKey, Double, ForeignKeyConstraint


class FuturePriceFeedAssociation(Base):
    __tablename__ = "future_price_feed_associations"
    __table_args__ = (
        ForeignKeyConstraint(
            ["feed_id", "feed_origin"],
            ["price_feeds.feed_id", "price_feeds.origin"],
            name="future_price_feed_assoc_feed_comp_fkey",
        ),
    )
    future_symbol: Mapped[str] = mapped_column(
        ForeignKey("futures.symbol"), primary_key=True
    )
    feed_id: Mapped[str] = mapped_column(primary_key=True)
    feed_origin: Mapped[str] = mapped_column(primary_key=True)
    weighting: Mapped[float] = mapped_column(Double, default=1.0, primary_key=True)

    future: Mapped["upestatic.future.Future"] = relationship(
        back_populates="underlying_feeds", lazy="immediate"
    )
    feed: Mapped["upestatic.price_feed.PriceFeed"] = relationship(
        back_populates="futures",
        lazy="immediate",
        foreign_keys="[FuturePriceFeedAssociation.feed_id, FuturePriceFeedAssociation.feed_origin]",
    )
