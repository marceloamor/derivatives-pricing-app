import upestatic.vol_surface_history
from upestatic.base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy import Integer, DateTime, Text
from sqlalchemy_json import mutable_json_type

from typing import Dict, Any, List
from datetime import datetime


class VolSurface(Base):
    __tablename__ = "vol_surfaces"
    vol_surface_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    model_type: Mapped[str] = mapped_column(Text)
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    params: Mapped[Dict[str, Any]] = mapped_column(mutable_json_type(JSON, nested=True))

    historical_surfaces: Mapped[
        List["upestatic.vol_surface_history.HistoricalVolSurface"]
    ] = relationship(back_populates="live_vol_surface")
