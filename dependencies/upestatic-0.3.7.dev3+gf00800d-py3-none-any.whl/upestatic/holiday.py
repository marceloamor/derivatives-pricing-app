import upestatic.holiday_association
import upestatic.product
from upestatic.base import Base

from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import (
    Date,
    BigInteger,
    Float,
    Text,
)
from sqlalchemy.orm import relationship

from datetime import date
from typing import List


class Holiday(Base):
    __tablename__ = "holidays"
    holiday_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    holiday_date: Mapped[date] = mapped_column(Date)
    holiday_weight: Mapped[float] = mapped_column(Float, default=1)

    products: Mapped[List["upestatic.product.Product"]] = relationship(
        secondary=upestatic.holiday_association.product_holiday_associations,
        back_populates="holidays",
    )
