import upestatic.product
from upestatic.base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Text

from typing import List


class Currency(Base):
    __tablename__ = "currencies"

    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    iso_symbol: Mapped[str] = mapped_column(Text)
    name: Mapped[str] = mapped_column(Text)

    products: Mapped[List["upestatic.product.Product"]] = relationship(
        back_populates="currency"
    )
