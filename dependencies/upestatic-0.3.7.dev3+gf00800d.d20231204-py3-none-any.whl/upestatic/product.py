from upestatic.holiday_association import product_holiday_associations
import upestatic.future_price_feed_association
from upestatic.base import Base
import upestatic.external_pnl
import upestatic.currency
import upestatic.exchange
import upestatic.holiday
import upestatic.future
import upestatic.option

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import ForeignKey, Text
from sqlalchemy.types import Time

from zoneinfo import ZoneInfo
from datetime import time
from typing import List


class Product(Base):
    __tablename__ = "products"

    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    short_name: Mapped[str] = mapped_column(Text)
    long_name: Mapped[str] = mapped_column(Text)
    currency_symbol: Mapped[str] = mapped_column(ForeignKey("currencies.symbol"))
    exchange_symbol: Mapped[int] = mapped_column(ForeignKey("exchanges.symbol"))
    market_open: Mapped[time] = mapped_column(
        Time(timezone=True), default=time(0, 0, 0, 0, tzinfo=ZoneInfo("UTC"))
    )
    market_close: Mapped[time] = mapped_column(
        Time(timezone=True), default=time(23, 59, 59, 999999, tzinfo=ZoneInfo("UTC"))
    )

    currency: Mapped["upestatic.currency.Currency"] = relationship(
        foreign_keys=currency_symbol, back_populates="products", lazy="immediate"
    )
    exchange: Mapped["upestatic.exchange.Exchange"] = relationship(
        foreign_keys=exchange_symbol, back_populates="products", lazy="immediate"
    )
    holidays: Mapped[List["upestatic.holiday.Holiday"]] = relationship(
        secondary=product_holiday_associations,
        back_populates="products",
        lazy="immediate",
    )
    futures: Mapped[List["upestatic.future.Future"]] = relationship(
        back_populates="product"
    )
    options: Mapped[List["upestatic.option.Option"]] = relationship(
        back_populates="product"
    )
    external_pnls: Mapped[List["upestatic.external_pnl.ExternalPnL"]] = relationship(
        back_populates="product"
    )
