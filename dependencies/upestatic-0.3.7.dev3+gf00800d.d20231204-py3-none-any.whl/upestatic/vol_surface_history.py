from upestatic.base import Base
import upestatic.vol_surface

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import DateTime, Text, ForeignKey
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy_json import mutable_json_type

from datetime import datetime
from typing import Dict, Any


class HistoricalVolSurface(Base):
    __tablename__ = "historical_vol_params"
    update_datetime: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), primary_key=True
    )
    vol_surface_id: Mapped[int] = mapped_column(
        ForeignKey("vol_surfaces.vol_surface_id"), primary_key=True
    )
    model_type: Mapped[str] = mapped_column(Text)
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    params: Mapped[Dict[str, Any]] = mapped_column(mutable_json_type(JSON, nested=True))

    live_vol_surface: Mapped["upestatic.vol_surface.VolSurface"] = relationship(
        back_populates="historical_surfaces"
    )
