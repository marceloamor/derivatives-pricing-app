from datetime import datetime
from typing import List, Optional, Tuple

from sqlalchemy import (
    ARRAY,
    DateTime,
    Double,
    Enum,
    ForeignKey,
    Integer,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.static_data.future as future
import upedata.static_data.product as product
from upedata.dynamic_data.vol_surface import VolSurface

from ..base import Base
from ..enums import TimeType, VolType


class Option(Base):
    __tablename__ = "options"
    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    display_name: Mapped[Optional[str]] = mapped_column(Text)
    product_symbol: Mapped[str] = mapped_column(ForeignKey("products.symbol"))
    vol_surface_id: Mapped[int] = mapped_column(
        ForeignKey("vol_surfaces.vol_surface_id")
    )
    underlying_future_symbol: Mapped[str] = mapped_column(ForeignKey("futures.symbol"))
    strike_intervals: Mapped[List[Tuple[int, int]]] = mapped_column(
        ARRAY(Integer, dimensions=2)
    )
    time_type: Mapped[TimeType] = mapped_column(Enum(TimeType, name="time_type"))
    multiplier: Mapped[float] = mapped_column(Double)
    vol_type: Mapped[VolType] = mapped_column(Enum(VolType, name="vol_type"))
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))

    product: Mapped["product.Product"] = relationship(
        foreign_keys=product_symbol, back_populates="options", lazy="immediate"
    )
    vol_surface: Mapped["VolSurface"] = relationship(
        foreign_keys=vol_surface_id, lazy="immediate"
    )
    underlying_future: Mapped["future.Future"] = relationship(
        foreign_keys=underlying_future_symbol,
        back_populates="options",
        lazy="immediate",
    )

    def to_dict(self):
        option_dict = {}
        for field in self.__table__.c:
            option_dict[field.name] = getattr(self, field.name)

        return option_dict

    def get_strikes(self, **kwargs):
        return strike_unpacker(self.strike_intervals, **kwargs)


def strike_unpacker(
    strike_intervals: List[Tuple[int, int]], strike_dps=5
) -> List[float]:
    """Utility static method that generates a list of strikes based on a packed
    strike interval construct, as found in static data.

    :param strike_intervals: Packed strike interval construct, using the same
    format as found in static data, e.g. [(100, 10), (200, 20), (300, -1)]
    would yield a 1D-list composed of [range(100, 200, 10), range(200, 300, 20), 300].
    A sentinel negative step width is required in the last tuple in the packed
    construct to tell the unpacker where to stop, the strike number this is attached
    to is included in the unpacked list, all strikes are then divided by the magnitude
    of this sentinel value (such that decimal strikes can be created).
    :type strike_intervals: List[Tuple[int, int]]
    :return: Unpacked list of strikes
    :rtype: List[float]
    """
    strike_list: List[float] = []
    strike_interval_stepwidth = 1  # initialise to prevent errors on None inputs
    strike_scaling_factor = 1
    for i, (strike_interval_start, strike_interval_stepwidth) in enumerate(
        strike_intervals
    ):
        if strike_interval_stepwidth < 0:
            strike_list.append(strike_interval_start)
            strike_scaling_factor = abs(1.0 / strike_interval_stepwidth)
            break
        try:
            strike_list.extend(
                range(
                    strike_interval_start,
                    strike_intervals[i + 1][0],
                    strike_interval_stepwidth,
                )
            )
        except IndexError:
            pass

    strike_list = [
        round(strike * strike_scaling_factor, strike_dps) for strike in strike_list
    ]

    return strike_list
