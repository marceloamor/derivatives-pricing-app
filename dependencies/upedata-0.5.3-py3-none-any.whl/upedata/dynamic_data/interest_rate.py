from datetime import date
from decimal import Decimal

from sqlalchemy import Date, ForeignKey, Numeric, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import Base
from ..static_data import currency


class InterestRate(Base):
    __tablename__ = "interest_rates"

    published_date: Mapped[date] = mapped_column(Date, primary_key=True)
    to_date: Mapped[date] = mapped_column(Date, primary_key=True)
    currency_symbol: Mapped[str] = mapped_column(
        ForeignKey("currencies.symbol"), primary_key=True
    )
    source: Mapped[str] = mapped_column(Text, primary_key=True)
    continuous_rate: Mapped[Decimal] = mapped_column(Numeric(12, 7))

    currency: Mapped["currency.Currency"] = relationship()

    def to_dict(self):
        inr_dict = {}
        for field in self.__table__.c:
            inr_dict[field.name] = getattr(self, field.name)

        return inr_dict
