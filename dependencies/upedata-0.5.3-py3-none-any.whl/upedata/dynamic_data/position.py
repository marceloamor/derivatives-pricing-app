from sqlalchemy import ForeignKey, Integer, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.static_data.portfolio as portfolio

from ..base import Base


class Position(Base):
    __tablename__ = "positions"

    instrument_symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.portfolio_id"))
    long_quantity: Mapped[int] = mapped_column(Integer)
    short_quantity: Mapped[int] = mapped_column(Integer)
    net_quantity: Mapped[int] = mapped_column(Integer)

    portfolio: Mapped["portfolio.Portfolio"] = relationship(
        back_populates="positions", lazy="immediate"
    )
