import upestatic.holiday_association
from upestatic.base import Base
import upestatic.product

from sqlalchemy import Date, BigInteger, Float, Column
from sqlalchemy.orm import relationship


class Holiday(Base):
    __tablename__ = "holidays"
    holiday_id = Column(BigInteger, primary_key=True, autoincrement=True)
    holiday_date = Column(Date, nullable=False)
    holiday_weight = Column(Float, default=1, nullable=False)

    products = relationship(
        "Product",
        secondary="product_holiday_associations",
        back_populates="holidays",
    )
