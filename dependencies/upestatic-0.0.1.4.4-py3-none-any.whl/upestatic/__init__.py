"""UPEStatic Module, provides ORM in a portable format for the new static data
standard"""

from upestatic.future_price_feed_association import FuturePriceFeedAssociation
from upestatic.vol_surface_history import HistoricalVolSurface
from upestatic.settlement_vol import SettlementVol
from upestatic.external_pnl import ExternalPnL
from upestatic.enums import VolType, TimeType
from upestatic.vol_surface import VolSurface
from upestatic.price_feed import PriceFeed
from upestatic.currency import Currency
from upestatic.exchange import Exchange
from upestatic.holiday import Holiday
from upestatic.product import Product
from upestatic.future import Future
from upestatic.option import Option
