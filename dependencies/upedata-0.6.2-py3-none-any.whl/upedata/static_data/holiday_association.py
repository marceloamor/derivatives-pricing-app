from sqlalchemy import Column, ForeignKey, Table

from ..base import Base

product_holiday_associations = Table(
    "product_holiday_associations",
    Base.metadata,
    Column("product_symbol", ForeignKey("products.symbol"), primary_key=True),
    Column("holiday_id", ForeignKey("holidays.holiday_id"), primary_key=True),
)
