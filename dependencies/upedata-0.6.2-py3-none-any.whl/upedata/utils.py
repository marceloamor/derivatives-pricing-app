from typing import Dict

NS_MICROSECOND = 1_000
NS_MILLISECOND = 1_000_000
NS_SECOND = 1_000_000_000
NS_MINUTE = 60_000_000_000
NS_HOUR = 3_600_000_000_000


def parse_str_duration(duration: str) -> Dict[str, int]:
    """A function built to behave as closely as possible to the
    polars duration parser.
    https://docs.pola.rs/docs/python/version/0.20/reference/expressions/api/polars.Expr.dt.offset_by.html

    This function will be migrated to C or Rust and made callable
    from a wrapper in both vectorised and scalar implementations.

    This implementation attempts to mirror that of the polars-time crate's
    `Duration::parse` function.

    :param duration: A duration string meeting the specification
    provided in the above URL
    :type duration: str
    :raises ValueError: If multiple negative signs are present in the string
    :raises ValueError: If a negative sign is present anywhere but at the
    start of the string
    :raises ValueError: If an unrecognised unit symbol is found (consult URL above)
    :raises ValueError: If no integers are found in the duration string
    :return: A dictionary mapping unit keys [ns, days, weeks, months] to
    integer values representing the number of each in the duration, for
    downstream use in library of user's choice
    :rtype: Dict[str, int]
    """
    num_minus_signs = duration.count("-")
    if num_minus_signs > 1:
        raise ValueError("Duration strings may only have one minus sign")
    is_negative = duration.startswith("-")
    if num_minus_signs > 0 and not is_negative:
        raise ValueError(
            "Only one minus sign at the start of a duration is string is allowed"
        )

    str_iter = enumerate(duration)
    if is_negative:
        substr_start = 1
        str_iter.__next__()
    else:
        substr_start = 0

    ns = 0
    days = 0
    weeks = 0
    months = 0

    curr_unit = ""
    for iter_index, char in str_iter:
        if not char.isdigit():
            try:
                n_units = int(duration[substr_start:iter_index])
            except ValueError as e:
                e.add_note("Expected an integer in duration string")
                raise e
            while True:
                if char.isalpha():
                    curr_unit += char
                else:
                    break
                try:
                    match str_iter.__next__():
                        case (iter_index, char_new):
                            char = char_new
                            substr_start = iter_index
                        case _:
                            break
                except StopIteration:
                    break
            if not curr_unit:
                raise ValueError("Expected unit in duration string")

            match curr_unit:
                case "ns":
                    ns += n_units
                case "us":
                    ns += n_units * NS_MICROSECOND
                case "ms":
                    ns += n_units * NS_MILLISECOND
                case "s":
                    ns += n_units * NS_SECOND
                case "h":
                    ns += n_units * NS_HOUR
                case "d":
                    days += n_units
                case "w":
                    weeks += n_units
                case "m":
                    months += n_units
                case "q":
                    months += n_units * 3
                case "y":
                    months += n_units * 12
                case _:
                    raise ValueError("Unrecognised unit type in duration string")
            curr_unit = ""

    if is_negative:
        ns *= -1
        days *= -1
        weeks *= -1
        months *= -1

    return {"ns": ns, "days": days, "weeks": weeks, "months": months}
