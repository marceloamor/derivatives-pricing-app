from datetime import date
from decimal import Decimal

from sqlalchemy import DECIMAL, Date, ForeignKey, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from ..base import Base
from ..static_data import currency


class ExchangeRate(Base):
    __tablename__ = "exchange_rates"

    published_date: Mapped[date] = mapped_column(Date, primary_key=True)
    source: Mapped[str] = mapped_column(Text, primary_key=True)
    base_currency_symbol: Mapped[str] = mapped_column(
        ForeignKey("currencies.symbol"), primary_key=True
    )
    quote_currency_symbol: Mapped[str] = mapped_column(
        ForeignKey("currencies.symbol"), primary_key=True
    )
    forward_date: Mapped[date] = mapped_column(Date, primary_key=True)
    rate: Mapped[Decimal] = mapped_column(DECIMAL(20, 8))

    base_currency: Mapped["currency.Currency"] = relationship(
        foreign_keys=base_currency_symbol
    )
    quote_currency: Mapped["currency.Currency"] = relationship(
        foreign_keys=quote_currency_symbol
    )

    def to_dict(self):
        exr_dict = {}
        for field in self.__table__.c:
            exr_dict[field.name] = getattr(self, field.name)

        return exr_dict
