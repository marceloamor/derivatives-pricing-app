import upestatic.future_price_feed_association
import upestatic.product
from upestatic.base import Base
import upestatic.option

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import ForeignKey, Integer, DateTime, Text

from datetime import datetime
from typing import List


class Future(Base):
    __tablename__ = "futures"

    symbol: Mapped[str] = mapped_column(Text, primary_key=True)
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    multiplier: Mapped[int] = mapped_column(Integer)
    product_symbol: Mapped[str] = mapped_column(ForeignKey("products.symbol"))

    product: Mapped["upestatic.product.Product"] = relationship()
    underlying_feeds: Mapped[
        List["upestatic.future_price_feed_association.FuturePriceFeedAssociation"]
    ] = relationship(back_populates="future")
    options: Mapped[List["upestatic.option.Option"]] = relationship(
        back_populates="underlying_future"
    )
