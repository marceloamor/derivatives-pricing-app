from upestatic.base import Base

from sqlalchemy import Integer, DateTime, Text

from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy_json import mutable_json_type


from datetime import datetime
from typing import Dict, Any


class VolSurface(Base):
    __tablename__ = "vol_surfaces"
    vol_surface_id: Mapped[int] = mapped_column(Integer, primary_key=True)
    model_type: Mapped[str] = mapped_column(Text)
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    params: Mapped[Dict[str, Any]] = mapped_column(mutable_json_type(JSON, nested=True))
