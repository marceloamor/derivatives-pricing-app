import upestatic.future_price_feed_association
from upestatic.base import Base

from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import Boolean, Text, ForeignKey

from typing import List


class PriceFeed(Base):
    __tablename__ = "price_feeds"

    feed_id: Mapped[str] = mapped_column(Text, primary_key=True)
    origin: Mapped[str] = mapped_column(Text, primary_key=True)
    delayed: Mapped[bool] = mapped_column(Boolean)
    subscribe: Mapped[bool] = mapped_column(Boolean)

    futures: Mapped[
        List["upestatic.future_price_feed_association.FuturePriceFeedAssociation"]
    ] = relationship(back_populates="feed")
