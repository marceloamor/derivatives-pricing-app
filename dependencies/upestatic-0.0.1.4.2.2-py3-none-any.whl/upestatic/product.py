from upestatic.holiday_association import product_holiday_associations
import upestatic.future_price_feed_association
from upestatic.base import Base
import upestatic.currency
import upestatic.exchange
import upestatic.holiday
import upestatic.future
import upestatic.option

from sqlalchemy.dialects.postgresql import TIME
from sqlalchemy import ForeignKey, Text, Column
from sqlalchemy.orm import relationship

from typing import List


class Product(Base):
    __tablename__ = "products"

    symbol = Column(Text, primary_key=True)
    short_name = Column(Text, nullable=False)
    long_name = Column(Text, nullable=False)
    currency_symbol = Column(Text, ForeignKey("currencies.symbol"), nullable=False)
    exchange_symbol = Column(Text, ForeignKey("exchanges.symbol"), nullable=False)
    market_open = Column(
        TIME(timezone=True),
        nullable=False,
        server_default="'00:00:00+00'::time with time zone",
    )
    market_close = Column(
        TIME(timezone=True),
        nullable=False,
        server_default="'23:59:59.999999+00'::time with time zone",
    )

    currency = relationship(
        "Currency",
        foreign_keys=currency_symbol,
        back_populates="products",
        lazy="immediate",
    )
    exchange = relationship(
        "Exchange",
        foreign_keys=exchange_symbol,
        back_populates="products",
        lazy="immediate",
    )
    holidays = relationship(
        "Holiday",
        secondary=product_holiday_associations,
        back_populates="products",
        lazy="immediate",
    )
    futures = relationship("Future", back_populates="product")
    options = relationship("Option", back_populates="product")
