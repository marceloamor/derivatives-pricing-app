import datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import Enum, ForeignKey, Numeric
from sqlalchemy.dialects.postgresql import DATE as pg_DATE
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.static_data.option as option

from ..base import Base
from ..enums import CallOrPut


class OptionClosingPrice(Base):
    __tablename__ = "option_closing_prices"

    close_date: Mapped[datetime.date] = mapped_column(pg_DATE, primary_key=True)
    option_symbol: Mapped[str] = mapped_column(
        ForeignKey("options.symbol"), primary_key=True
    )
    option_strike: Mapped[Decimal] = mapped_column(Numeric(20, 8), primary_key=True)
    call_or_put: Mapped[CallOrPut] = mapped_column(
        Enum(CallOrPut, name="call_or_put"), primary_key=True
    )
    close_price: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(20, 8), nullable=True
    )
    close_volatility: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(12, 8), nullable=True
    )
    close_delta: Mapped[Optional[Decimal]] = mapped_column(Numeric(9, 8), nullable=True)

    option: Mapped["option.Option"] = relationship()

    def to_dict(self):
        ocp_dict = {}
        for field in self.__table__.c:
            ocp_dict[field.name] = getattr(self, field.name)

        return ocp_dict
