from datetime import datetime
from typing import List

from sqlalchemy import BigInteger, DateTime, Enum, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.dynamic_data.trade as trade

from ..base import Base
from ..enums import RoutingStatus as RoutingStatusEnum


class RoutingStatus(Base):
    __tablename__ = "routing_statuses"

    routing_status_id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    created_utc: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), server_default="now_utc()"
    )
    last_update_utc: Mapped[datetime] = mapped_column(
        DateTime(timezone=False), server_default="now_utc()"
    )
    status: Mapped[RoutingStatusEnum] = mapped_column(
        Enum(RoutingStatusEnum, name="routing_status"),
        server_default="'BUILDING'::routing_status",
    )
    destination: Mapped[str] = mapped_column(Text)
    additional_information: Mapped[str] = mapped_column(Text)

    trades: Mapped[List["trade.Trade"]] = relationship(back_populates="routing_status")
