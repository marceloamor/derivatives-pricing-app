from datetime import datetime
from typing import Any, Dict

from sqlalchemy import DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy_json import mutable_json_type

import upedata.dynamic_data.vol_surface as vol_surface

from ..base import Base


class HistoricalVolSurface(Base):
    __tablename__ = "historical_vol_params"
    update_datetime: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), primary_key=True
    )
    vol_surface_id: Mapped[int] = mapped_column(
        ForeignKey("vol_surfaces.vol_surface_id"), primary_key=True
    )
    model_type: Mapped[str] = mapped_column(Text)
    expiry: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    params: Mapped[Dict[str, Any]] = mapped_column(mutable_json_type(JSON, nested=True))

    live_vol_surface: Mapped["vol_surface.VolSurface"] = relationship(
        back_populates="historical_surfaces"
    )
