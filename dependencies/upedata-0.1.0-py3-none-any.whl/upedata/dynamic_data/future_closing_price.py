import datetime
from decimal import Decimal

from sqlalchemy import ForeignKey, Numeric
from sqlalchemy.dialects.postgresql import DATE as pg_DATE
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.static_data.future as future

from ..base import Base


class FutureClosingPrice(Base):
    __tablename__ = "future_closing_prices"

    close_date: Mapped[datetime.date] = mapped_column(pg_DATE, primary_key=True)
    future_symbol: Mapped[str] = mapped_column(
        ForeignKey("futures.symbol"), primary_key=True
    )
    close_price: Mapped[Decimal] = mapped_column(Numeric(20, 8))

    future: Mapped["future.Future"] = relationship()

    def to_dict(self):
        fcp_dict = {}
        for field in self.__table__.c:
            fcp_dict[field.name] = getattr(self, field.name)

        return fcp_dict
