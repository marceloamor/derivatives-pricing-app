from datetime import datetime
from typing import Optional

from sqlalchemy import BigInteger, Boolean, Float, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import TIMESTAMP
from sqlalchemy.orm import Mapped, mapped_column, relationship

import upedata.dynamic_data.routing_status as routing_status
import upedata.static_data.portfolio as portfolio
import upedata.static_data.trader as trader

from ..base import Base


class Trade(Base):
    __tablename__ = "trades"

    trade_pk: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    trade_datetime_utc: Mapped[datetime] = mapped_column(TIMESTAMP(timezone=False))
    instrument_symbol: Mapped[str] = mapped_column(Text)
    quantity: Mapped[int] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Float)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.portfolio_id"))
    trader_id: Mapped[int] = mapped_column(ForeignKey("traders.trader_id"))
    notes: Mapped[str] = mapped_column(Text)
    deleted: Mapped[Boolean] = mapped_column(Boolean, default=False)
    venue_name: Mapped[str] = mapped_column(Text)
    venue_trade_id: Mapped[str] = mapped_column(Text)
    counterparty: Mapped[str] = mapped_column(Text)
    routing_status_id: Mapped[Optional[int]] = mapped_column(
        ForeignKey("routing_statuses.routing_status_id")
    )

    trader: Mapped["trader.Trader"] = relationship(foreign_keys=trader_id)
    portfolio: Mapped["portfolio.Portfolio"] = relationship(foreign_keys=portfolio_id)
    routing_status: Mapped[Optional["routing_status.RoutingStatus"]] = relationship(
        foreign_keys=routing_status_id, back_populates="trades"
    )

    def to_dict(self):
        trade_dict = {}
        for field in self.__table__.c:
            trade_dict[field.name] = getattr(self, field.name)

        return trade_dict
