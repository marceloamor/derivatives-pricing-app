from upestatic.base import Base
import upestatic.product

from sqlalchemy.orm import relationship
from sqlalchemy import Text, Column


class Currency(Base):
    __tablename__ = "currencies"

    symbol = Column(Text, primary_key=True)
    iso_symbol = Column(Text, nullable=False)
    name = Column(Text, nullable=False)

    products = relationship("Product", back_populates="currency")
